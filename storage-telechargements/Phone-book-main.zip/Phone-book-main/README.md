# Phone-book
Project phone-book only using Powershell ( School System and Network Tech )

Copier le dossier "ScriptAnnuaire" à la racine du disque "C:".
