# CleanZiiChannel
Simple bot discord (clean)
