# CSveditorJS
School project

Requirements:
NodeJS

Tuto:

- npm init -y
- npm i express body-parser nodemon
- npm i csv-stringify
- npm i multer csv-parse
- run = node index.js 
