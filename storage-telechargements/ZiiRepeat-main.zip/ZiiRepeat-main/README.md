# ZiiRepeat
Simple bot discord (remind)
